using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class AmbrosiumSword : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ambrosium Sword");
			Tooltip.SetDefault("'Harnesses the power of the gods'");
		}
		public override void SetDefaults()
		{
			item.width = 40;
			item.height = 40;
			item.useTime = 35;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.rare = 2;
			item.melee = true;
			item.maxStack = 1;
			item.value = 31200;
			item.damage = 38;
			item.knockBack = 7;
			item.UseSound = SoundID.Item1;
			item.scale = 1.5F;
			item.autoReuse = true;
		}
		
		public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            target.AddBuff(BuffID.OnFire, 1 * 10);
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("AmbrosiumBar"), 8);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
