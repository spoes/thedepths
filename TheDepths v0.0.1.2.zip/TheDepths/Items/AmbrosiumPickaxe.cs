using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class AmbrosiumPickaxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ambrosium Pickaxe");
			Tooltip.SetDefault("'Harnesses the power of the gods'");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 32;
			item.useTime = 15;
			item.useAnimation = 15;
			item.useStyle = 1;
			item.rare = 2;
			item.melee = true;
			item.pick = 85;
			item.maxStack = 1;
			item.value = 38600;
			item.damage = 11;
			item.knockBack = 4;
			item.UseSound = SoundID.Item1;
			item.scale = 1.5F;
			item.autoReuse = true;
		}
		
		public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            target.AddBuff(BuffID.OnFire, 1 * 5);
        }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("AmbrosiumBar"), 12);
			recipe.AddRecipeGroup("Wood", 2);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
