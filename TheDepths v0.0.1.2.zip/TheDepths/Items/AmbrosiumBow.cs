using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class AmbrosiumBow : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ambrosium Bow");
			Tooltip.SetDefault("'Harnesses the power of the gods'");
		}
		public override void SetDefaults()
		{
			item.width = 40;
			item.height = 40;
			item.useTime = 15;
			item.useAnimation = 15;
			item.useStyle = 5;
			item.shootSpeed = 10F;
			item.rare = 2;
			item.ranged = true;
			item.noMelee = true;
			item.maxStack = 1;
			item.value = 28000;
			item.damage = 18;
			item.knockBack = 3;
			item.shoot = 1;
			item.UseSound = SoundID.Item1;
			item.scale = 1.5F;
			item.autoReuse = true;
			item.useAmmo = AmmoID.Arrow;
		}
		
		

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("AmbrosiumBar"), 8);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
