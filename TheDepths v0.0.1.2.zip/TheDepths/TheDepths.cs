using Terraria.ModLoader;

namespace TheDepths
{
	class TheDepths : Mod
	{
		public TheDepths()
		{
			Properties = new ModProperties()
			{
				Autoload = true,
				AutoloadGores = true,
				AutoloadSounds = true
			};
		}
	}
}
