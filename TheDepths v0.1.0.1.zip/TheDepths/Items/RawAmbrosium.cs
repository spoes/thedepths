using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class RawAmbrosium : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Raw Ambrosium");
			Tooltip.SetDefault("'Carried by messengers of the gods'\n'Also tasty and flammable'");
		}
		public override void SetDefaults()
		{
			item.width = 16;
			item.height = 14;
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.rare = 0;
			item.maxStack = 999;
			item.value = 1200;
			item.UseSound = SoundID.Item1;
		}
	}
}
