using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class AmbrosiumBar : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ambrosium Bar");
			Tooltip.SetDefault("'Said to harness the power of the gods'");
		}
		public override void SetDefaults()
		{
			item.width = 30;
			item.height = 24;
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.rare = 2;
			item.maxStack = 99;
			item.value = 12400;
			item.UseSound = SoundID.Item1;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.GoldBar, 10);
			recipe.AddIngredient(ItemID.DemoniteBar, 5);
			recipe.AddIngredient(mod.GetItem("RawAmbrosium"), 2);
			recipe.AddTile(TileID.Furnaces);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
