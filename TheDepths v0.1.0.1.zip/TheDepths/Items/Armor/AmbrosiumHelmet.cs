using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items.Armor
{
	[AutoloadEquip(EquipType.Head)]
	public class AmbrosiumHelmet : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("'Harnesses the power of the gods'"
			+ "\nIncreases magic critical strike chance by 4%");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 32500;
			item.rare = 2;
			item.defense = 7;
		}

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
			return head.type == mod.ItemType("AmbrosiumHelmet") && body.type == mod.ItemType("ExampleBreastplate") && legs.type == mod.ItemType("ExampleLeggings");
		}
		
		public override void UpdateEquip(Player player)
		{
			player.magicCrit += 4;
		}

		public override void UpdateArmorSet(Player player)
		{
			player.setBonus = "I AM A TEST DON'T LOOK AT ME\nIncreases running acceleration by 15%";
			player.runAcceleration *= 0.15f;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("AmbrosiumBar"), 15);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}