using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items.Armor
{
	[AutoloadEquip(EquipType.Body)]
	public class AmbrosiumBreastplate : ModItem
	{
		public override void SetStaticDefaults()
		{
			base.SetStaticDefaults();
			DisplayName.SetDefault("Ambrosium Breastplate");
			Tooltip.SetDefault("'Harnesses the power of the gods'"
				+ "\nIncreases maximum life by 20");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 45000;
			item.rare = 2;
			item.defense = 8;
		}
		
		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
			return body.type == mod.ItemType("AmbrosiumBreastplate") && legs.type == mod.ItemType("AmbrosiumLeggings");
		}

		public override void UpdateEquip(Player player)
		{
			player.statLifeMax2 += 20;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.GetItem("AmbrosiumBar"), 25);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}