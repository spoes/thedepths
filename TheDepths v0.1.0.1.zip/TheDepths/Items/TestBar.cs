using Terraria.ID;
using Terraria.ModLoader;

namespace TheDepths.Items
{
	public class TestBar : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("TestBar");
			Tooltip.SetDefault("This is probably some form of test...");
		}
		public override void SetDefaults()
		{
			item.width = 30;
			item.height = 24;
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.rare = 1;
			item.maxStack = 99;
			item.value = 4500;
			item.UseSound = SoundID.Item1;
		}

		/*public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.IronBar, 3);
			recipe.AddIngredient(ItemID.DemoniteBar, 2);
			recipe.AddTile(TileID.Furnaces);
			recipe.SetResult(this, 2);
			recipe.AddRecipe();
		}*/
	}
}
